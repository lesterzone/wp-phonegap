'use strict';

ons.bootstrap();
ons.ready(function() {
	menu.openMenuMenu();
});